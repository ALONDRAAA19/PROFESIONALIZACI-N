function agregarServicio() {
    const precioMes = 1200;
    const precioAño = 14000;

    const meses = parseInt(document.getElementById("meses1").value) || 0;
    const años = parseInt(document.getElementById("años1").value) || 0;

    const total = (meses * precioMes) + (años * precioAño);
    const mensaje = `Total a pagar: $${total.toLocaleString()}`;

    totalElemento.textContent = `Total a pagar: $${total.toLocaleString()}`;

    document.getElementById("total1").textContent = mensaje;
    if (total > 0) {
        agregarProductoAlCarrito("IT Service Management", total, meses, años);
    }
}

function agregarServicio2() {
    const meses = parseInt(document.getElementById("meses2").value) || 0;
    const años = parseInt(document.getElementById("años2").value) || 0;
    const precioMes = 2000;
    const precioAño = 22000;
    
    const total = (meses * precioMes) + (años * precioAño);
    
    const totalElemento = document.getElementById("total2");
    totalElemento.textContent = `Total a pagar: $${total.toLocaleString()}`;
    if (total > 0) {
        agregarProductoAlCarrito("IT Operations Management", total, meses, años);
    }
}

function agregarServicio3() {
    const meses = parseInt(document.getElementById("meses3").value) || 0;
    const años = parseInt(document.getElementById("años3").value) || 0;
    const precioMes = 3000;
    const precioAño = 35000;
    
    const total = (meses * precioMes) + (años * precioAño);

    const totalElemento = document.getElementById("total3");
    totalElemento.textContent = `Total a pagar: $${total.toLocaleString()}`;
    if (total > 0) {
        agregarProductoAlCarrito("IT Service Management", total, meses, años);
    }
}

function agregarServicio4() {
    const meses = parseInt(document.getElementById("meses4").value) || 0;
    const años = parseInt(document.getElementById("años4").value) || 0;
    const precioMes = 1200;
    const precioAño = 14000;
    
    const total = (meses * precioMes) + (años * precioAño);
    
    const totalElemento = document.getElementById("total4");
    totalElemento.textContent = `Total a pagar: $${total.toLocaleString()}`;
    if (total > 0) {
        agregarProductoAlCarrito("IT Service Management", total, meses, años);
    }
}

function agregarServicio5() {
    const meses = parseInt(document.getElementById("meses5").value) || 0;
    const años = parseInt(document.getElementById("años5").value) || 0;
    const precioMes = 700;
    const precioAño = 8000;
    
    const total = (meses * precioMes) + (años * precioAño);
    
    const totalElemento = document.getElementById("total5");
    totalElemento.textContent = `Total a pagar: $${total.toLocaleString()}`;
    if (total > 0) {
        agregarProductoAlCarrito("IT Service Management", total, meses, años);
    }
}

function agregarServicio6() {
    const meses = parseInt(document.getElementById("meses6").value) || 0;
    const años = parseInt(document.getElementById("años6").value) || 0;
    const precioMes = 1000;
    const precioAño = 11000;
    
    const total = (meses * precioMes) + (años * precioAño);
    
    const totalElemento = document.getElementById("total6");
    totalElemento.textContent = `Total a pagar: $${total.toLocaleString()}`;
    if (total > 0) {
        agregarProductoAlCarrito("IT Service Management", total, meses, años);
    }
}


document.addEventListener("DOMContentLoaded", actualizarTotalCarrito);

function removerProducto(elemento) {
    const productoCarrito = elemento.closest(".productos-carrito");
    productoCarrito.remove();
    actualizarTotalCarrito();
}


const btnCart = document.querySelector('.container-icon')

const contenedorCarrito = document.querySelector('.contenedor-carrito')


btnCart.addEventListener('click', () => {contenedorCarrito.classList.toggle('carrito-escondido')})

function generarTicket() {
    const productos = document.querySelectorAll('.productos-carrito');
    let contenidoTicket = `
        <p style="text-align:center;"><strong>InnovaTools</strong></p>
        <p style="text-align:center;">Fecha: ${new Date().toLocaleString()}</p>
        <hr>
        <table style="width:100%; margin-bottom:15px;">
            <tr>
                <th style="text-align:left;">Producto</th>
                <th style="text-align:right;">Precio</th>
            </tr>`;
    
    let subtotal = 0;
    const ivaPorcentaje = 0.16;

    productos.forEach(producto => {
        const nombre = producto.querySelector('.titulo-producto-carrito').textContent;
        const precioTexto = producto.querySelector('.precio-producto-carrito').textContent;
        const precio = parseFloat(precioTexto.replace(/[^0-9.-]+/g,""));


        contenidoTicket += `
            <tr>
                <td>${nombre}</td>
                <td style="text-align:right;">$${precio.toLocaleString()}</td>
            </tr>`;
        
        subtotal += precio;
    });

    const iva = subtotal * ivaPorcentaje;
    const total = subtotal + iva;
    
    contenidoTicket += `
        <tr>
            <td colspan="2"><hr></td>
        </tr>
        <tr>
            <td>Subtotal :><hr></td>
            <td style="text-align:right;">$${subtotal.toLocaleString()}</td>
        </tr>

        <tr>
            <td>IVA (${(ivaPorcentaje * 100)}%):</td>
            <td style="text-align:right;">$${iva.toLocaleString()}</td>
        </tr>

        <tr>
            <td><strong>Total:</strong></td>
            <td style="text-align:right;"><strong>$${total.toLocaleString()}</strong></td>
        </tr>
        
        </table>
        <hr>
        <p style="text-align:center;">¡Gracias por su compra!</p>
        <p style="text-align:center;">Visite nuestra página para más productos</p>`;
    
    document.getElementById('ticket-content').innerHTML = contenidoTicket;
    document.getElementById('ticket-modal').style.display = 'flex';
}

function imprimirTicket() {
    const ventana = window.open('', '', 'width=400,height=600');
    const contenido = document.getElementById('ticket-content').innerHTML;
    
    ventana.document.write(`
        <html>
            <head>
                <title>Ticket de Compra</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    table { width: 100%; margin-bottom: 15px; }
                    th { text-align: left; }
                    td { padding: 3px 0; }
                    .total { font-weight: bold; }
                </style>
            </head>
            <body>
                ${contenido}
                <script>
                    window.onload = function() {
                        window.print();
                        setTimeout(function() {
                            window.close();
                        }, 1000);
                    };
                </script>
            </body>
        </html>
    `);
    ventana.document.close();
}

function cerrarTicket() {
    document.getElementById('ticket-modal').style.display = 'none';
}


function agregarProductoAlCarrito(nombre, precio, meses, años) {
    const carrito = document.getElementById('carrito');
    const totalElemento = document.getElementById('total-carrito');
    
    const productoHTML = `
        <div class="productos-carrito">
            <div class="info-carrito">
                <span class="cantidad-producto-carrito">${meses > 0 ? meses + ' mes(es)' : años + ' año(s)'}</span>
                <p class="titulo-producto-carrito">${nombre}</p>
                <span class="precio-producto-carrito">$${precio.toLocaleString()}</span>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="icono-cancelar" onclick="removerProducto(this)">
                <path stroke-linecap="round" stroke-linejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
            </svg>
        </div>
    `;
    
    const totalCarritoDiv = carrito.querySelector('.total-carrito');
    carrito.insertBefore(createElementFromHTML(productoHTML), totalCarritoDiv);
    
    const productos = carrito.querySelectorAll('.productos-carrito').length - 1;
    document.getElementById('conteo-productos').textContent = productos;
    
    actualizarTotalCarrito();
}

function createElementFromHTML(htmlString) {
    const div = document.createElement('div');
    div.innerHTML = htmlString.trim();
    return div.firstChild;
}

function actualizarTotalCarrito() {
    const productos = document.querySelectorAll('.productos-carrito');
    let total = 0;
    
    productos.forEach(producto => {
        const precioTexto = producto.querySelector('.precio-producto-carrito').textContent;
        const precio = parseFloat(precioTexto.replace(/[^0-9.-]+/g,""));
        total += precio;
    });
    
    document.getElementById('total-carrito').textContent = `$${total.toLocaleString()}`;
}

function agregarServicio() {
    const precioMes = 1200;
    const precioAño = 14000;
    const meses = parseInt(document.getElementById("meses1").value) || 0;
    const años = parseInt(document.getElementById("años1").value) || 0;
    const total = (meses * precioMes) + (años * precioAño);
    
    if (total > 0) {
        agregarProductoAlCarrito("IT Service Management", total, meses, años);
    }
}


function removerProducto(elemento) {
    const productoCarrito = elemento.closest(".productos-carrito");
    productoCarrito.remove();
    actualizarTotalCarrito();
    
    // Actualizar contador de productos
    const productos = document.querySelectorAll('.productos-carrito').length;
    document.getElementById('conteo-productos').textContent = productos;
}

// Paso para validación de la tarjeta 
function mostrarFormularioPago() {
    const form = document.getElementById('formulario-pago');
    form.style.display = 'block';
    form.scrollIntoView({ behavior: 'smooth' });
}

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('tarjeta-form');

    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            const numero = document.getElementById('numero').value.trim();
            const mes = document.getElementById('mes').value.trim();
            const año = document.getElementById('año').value.trim();
            const cvv = document.getElementById('cvc').value.trim();

            if (!/^\d{16}$/.test(numero)) return alert('Número de tarjeta inválido');
            if (!/^\d{2}$/.test(mes) || mes < 1 || mes > 12) return alert('Mes inválido');
            if (!/^\d{2}$/.test(año)) return alert('Año inválido');
            if (!/^\d{3}$/.test(cvv)) return alert('CVC inválido');

            alert('¡Pago realizado con éxito!');
            form.reset();
            document.getElementById('formulario-pago').style.display = 'none';
        });
    }
});